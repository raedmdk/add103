Chrome Developer Tools — Assignment Starter

How to Use:
1) Open index.html in Chrome.
2) Right-click → Inspect (or press F12 / Ctrl+Shift+I).
3) In DevTools, open the Sources tab → css/styles.css.
4) Edit CSS rules live to meet this checklist:
   - Change body background color.
   - Style the image (#hero): width, border, and center.
   - Change font colors/families for headings and paragraphs.
   - Change list bullet types (UL and OL).
   - Change dt and dd colors.
5) Press Ctrl+S (Cmd+S on Mac) in DevTools to save your edits.
6) Push to GitHub → pull/deploy on cPanel.
7) Submit both links in Canvas.

Shortcuts:
- Open DevTools: F12 or Ctrl+Shift+I (Cmd+Option+I on Mac)
- Edit-and-save CSS from Sources panel.
- Box Model = content + padding + border + margin.
