
Raed's Final Version — Using Images

Alt text (my own words):
- Resort: "View of resort and the Dead Sea in Jordan with palm trees."
- Soccer Field: "Soccer stadium in Chicago with green field and stands."
- Chicago skyline: "Chicago skyline with tall buildings and Lake Michigan."
- External mountain: "Mountains above a lake, example external image from Wikipedia."
- MCC link: "Click to open the MCC website."

Checklist before submit:
1) Test map hotspots and fallback links.
2) Check float wrap text.
3) Resize browser window to see picture element swap images.
4) Make sure alt text matches my real photos.
