# ADD103 • GitHub → cPanel Demo

This folder is ready to upload to a **public GitHub repo** and connect in **cPanel → Git Version Control** at `public_html/ADD103`.

## What’s inside
- `index.html` — a simple test page (with the Ducktor mascot) to confirm your connection is live.
- `css/style.css` — minimal styles.
- `img/ducktor.svg` — original, simple mascot in SVG (no external links).
- `README.html` — step‑by‑step setup (same as below, handy on the live site).
- `SUBMISSION.md` — checklist for Canvas submission.

## One‑Time Setup (GitHub → cPanel)
1) **Make repo public** (GitHub → Settings → Danger Zone → Change visibility → Public).  
2) Click the green **Code** button → **HTTPS** tab → Copy the clone URL.  
3) **cPanel → Files → Git Version Control → Create**  
   - Clone URL: *paste your GitHub URL*  
   - Repository Path: `public_html/ADD103`  
   - Name: `ADD103`  
4) **Fix permissions**: File Manager → right‑click `public_html/ADD103` → Permissions → set to **755** → Recurse into subdirectories.  
5) **Test**: Open `https://YOURDOMAIN.com/ADD103/` — you should see the page and mascot.

## Future Updates
- Push changes to GitHub.
- cPanel → Git Version Control → **Pull or Deploy** → **Update from Remote**.

## Self‑Check Quiz (short answers)
1) Public lets cPanel clone without credentials.  
2) Green **Code** button → **HTTPS** tab URL.  
3) 755 lets the web server read/execute files; prevents 403/500 issues.  
4) Pull in cPanel; re‑check permissions.

Good luck!