# Canvas Submission Checklist

- [ ] I can open: `https://YOURDOMAIN.com/ADD103/index.html`
- [ ] I see the Ducktor Quacksalot mascot on the page
- [ ] I took a screenshot of **cPanel → Git Version Control** showing my repo
- [ ] I submitted the screenshot **or** my live URL in Canvas

**Optional URL to submit:**  
`https://YOURDOMAIN.com/ADD103/`
